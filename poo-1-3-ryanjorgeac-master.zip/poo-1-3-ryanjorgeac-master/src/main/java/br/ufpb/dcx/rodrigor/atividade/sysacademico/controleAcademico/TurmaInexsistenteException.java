package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

public class TurmaInexsistenteException extends Exception {
    public TurmaInexsistenteException(String msg) {
        super(msg);
    }
}
