package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

public class DepartamentoException extends Exception {
    public DepartamentoException(String msg) {
        super(msg);
    }
}
