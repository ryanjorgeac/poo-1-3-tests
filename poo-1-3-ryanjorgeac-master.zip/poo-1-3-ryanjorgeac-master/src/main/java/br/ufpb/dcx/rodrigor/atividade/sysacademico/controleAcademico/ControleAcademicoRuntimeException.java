package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

public class ControleAcademicoRuntimeException extends RuntimeException{
    public ControleAcademicoRuntimeException(String msg) {
        super(msg);
    }
}
