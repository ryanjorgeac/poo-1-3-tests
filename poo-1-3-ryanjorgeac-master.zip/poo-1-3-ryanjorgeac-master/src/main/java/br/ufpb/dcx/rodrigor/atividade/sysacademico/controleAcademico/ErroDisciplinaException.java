package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

public class ErroDisciplinaException extends RuntimeException{
    public ErroDisciplinaException(String msg) { super(msg); }
}
