package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Disciplina {


    private Curso curso;
    private String codigo;
    private String nome;
    private List<Turma> turmas;

    public Disciplina(String codigo, String nome, Curso curso) throws DepartamentoException {
        if (codigo.isEmpty()) {
            throw new DepartamentoException("O código da disciplina não pode ser vazio.");
        } else if (codigo.length() < 6 || codigo.length() > 10) {
            throw new DepartamentoException("O código da disciplina deve ter entre 6 e 10 caracteres.");
        } else if (!codigo.chars().allMatch(Character::isDigit)) {
            throw new DepartamentoException("O código da disciplina deve conter apenas números.");
        }

        if (nome.isEmpty()) {
            throw new DepartamentoException("O nome da disciplina não pode ser vazio.");
        } else if (nome.length() < 3) {
            throw  new DepartamentoException("O nome da disciplina não pode ter menos de 3 caracteres.");
        }

        if (Objects.isNull(curso)) {
            throw new CursoNotNullRuntimeException("Curso não deve ser null");
        }
        this.codigo = codigo;
        this.nome = nome;
        this.turmas = new ArrayList<>();
        this.curso = curso;
    }


    public Turma criarTurma() throws DepartamentoException {
        Turma novaTurma = new Turma(this,turmas.size()+1);
        this.turmas.add(novaTurma);
        return novaTurma;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String toString(){
        StringBuffer disciplinaStr = new StringBuffer(this.codigo+" - "+this.nome);
        if(!this.turmas.isEmpty()){
            disciplinaStr.append(" - turma(s): ");
            for(Turma turma: turmas)
                disciplinaStr.append(turma.getNumeroTurma()+" ");
        }
        return disciplinaStr.toString() ;
    }

    public String getCodigo() {
        return this.codigo;
    }

    public List<Turma> getTurmas() {
        return this.turmas;
    }

    public Turma getTurma(int turma) throws TurmaInexsistenteException {
        if(turma <= turmas.size()) {
            return turmas.get(turma-1);
        } else {
            throw new TurmaInexsistenteException("Turma inexistente.");
        }
    }

    public Curso getCurso(){
        return this.curso;
    }

}
