package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

public class CursoNotNullRuntimeException extends RuntimeException{
    public CursoNotNullRuntimeException(String msg) { super(msg); }
}
