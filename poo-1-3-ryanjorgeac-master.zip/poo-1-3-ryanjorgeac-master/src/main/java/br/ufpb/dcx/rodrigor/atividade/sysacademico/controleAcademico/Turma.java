package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Turma {

    private int numeroTurma;
    private Disciplina disciplina;

    private List<Aluno> alunos;
    public Turma(Disciplina disciplina, int numeroTurma) throws DepartamentoException {
        if (numeroTurma < 0) {
            throw new DepartamentoException("O número da turma deve ser um número maior ou igual a zero.");
        }
        if (Objects.isNull(disciplina)) {
            throw new ControleAcademicoRuntimeException("A disciplina de uma turma não pode ser nula.");
        }
        this.disciplina = disciplina;
        this.numeroTurma = numeroTurma;
        alunos = new LinkedList<>();
    }

    public int getNumeroTurma(){
        return this.numeroTurma;
    }

    public Disciplina getDisciplina(){
        return this.disciplina;
    }

    public String toString(){
        return this.disciplina.getNome()+": Turma "+this.numeroTurma;
    }

    public void matricularAluno(Aluno novoAluno) {
        Curso curso = disciplina.getCurso();
        if (!curso.getAlunos().containsValue(novoAluno)) {
            throw new ErroDisciplinaException("Aluno não cadastrado em um curso.");
        }
        this.alunos.add(novoAluno);
    }

    public List<Aluno> getAlunos() {
        return this.alunos;
    }
}
