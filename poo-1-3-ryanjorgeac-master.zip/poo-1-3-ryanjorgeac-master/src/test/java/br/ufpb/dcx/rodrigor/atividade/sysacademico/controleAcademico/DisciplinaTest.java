package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class DisciplinaTest {

    @Test
    void disciplinaNullCodigo() {
        try {
            Curso si = new Curso("123123123", "Sistemas de Informação");
            Disciplina disciplina = new Disciplina("","POO", si);
        } catch (DepartamentoException e) {
            assertEquals("O código da disciplina não pode ser vazio.", e.getMessage());

        }
    }

    @Test
    void disciplinaNullNome() {
        try {
            Curso si = new Curso("123123123", "Sistemas de Informação");
            Disciplina disciplina = new Disciplina("123456","", si);
        } catch (DepartamentoException e) {
            assertEquals("O nome da disciplina não pode ser vazio.", e.getMessage());

        }
    }

    @Test
    void disciplinaNomeMenorQue3Caracteres() {
        try {
            Curso si = new Curso("123123123", "Sistemas de Informação");
            Disciplina disciplina = new Disciplina("123456","PO", si);
        } catch (DepartamentoException e) {
            assertEquals("O nome da disciplina não pode ter menos de 3 caracteres.", e.getMessage());

        }
    }

    @Test
    void disciplinaCodigoEntre6e10Caracteres() {
        try {
            Curso si = new Curso("123123123", "Sistemas de Informação");
            Disciplina disciplina = new Disciplina("123", "POO", si);
        } catch (DepartamentoException e) {
            assertEquals("O código da disciplina deve ter entre 6 e 10 caracteres.", e.getMessage());
        }
    }

    @Test
    void disciplinaCodigoNumerico() {
        try {
            Curso si = new Curso("123123123", "Sistemas de Informação");
            Disciplina disciplina = new Disciplina("123abc", "POO", si);
        } catch (DepartamentoException e) {
            assertEquals("O código da disciplina deve conter apenas números.", e.getMessage());
        }
    }

    @Test
    void disciplinaTurmasVazias() throws DepartamentoException {
        Curso si = new Curso("123123123", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("123456", "POO", si);
        assertEquals(new ArrayList<>(), disciplina.getTurmas());
    }

    @Test
    void disciplinaTurmasSequenciais() throws DepartamentoException, TurmaInexsistenteException {
        Curso si = new Curso("123123123", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("123456", "POO", si);
        disciplina.criarTurma();
        disciplina.criarTurma();
        disciplina.criarTurma();
        assertEquals("POO: Turma 1", disciplina.getTurma(1).toString());
        assertEquals("POO: Turma 2", disciplina.getTurma(2).toString());
        assertEquals("POO: Turma 3", disciplina.getTurma(3).toString());

    }

    @Test
    void disciplinaTurmaMesmaDisciplina() throws DepartamentoException, TurmaInexsistenteException {
        Curso si = new Curso("123123123", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("123456", "POO", si);
        disciplina.criarTurma();
        assertEquals("123456 - POO - turma(s): 1 ", disciplina.getTurma(1).getDisciplina().toString());
    }

    @Test
    void disciplinaCursoNull() {
        try {
            Disciplina disciplina = new Disciplina("123456", "POO", null);
        } catch (RuntimeException | DepartamentoException e) {
            assertEquals("Curso não deve ser null", e.getMessage());
        }

    }

    @Test
    void disciplinaGetTurma() throws DepartamentoException, TurmaInexsistenteException {
        Curso si = new Curso("123123123", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("123456", "POO", si);
        disciplina.criarTurma();
        try {
            disciplina.getTurma(2);
        } catch (TurmaInexsistenteException e) {
            assertEquals("Turma Inexistente.", e.getMessage());
        }
    }
}