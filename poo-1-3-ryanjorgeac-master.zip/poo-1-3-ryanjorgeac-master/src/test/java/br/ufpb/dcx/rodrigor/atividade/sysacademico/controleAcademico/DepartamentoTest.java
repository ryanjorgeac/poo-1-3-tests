package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DepartamentoTest {

    @Test
    void DepartamentoNomeMenor3Caracteres() {
        try {
            Departamento departamento = new Departamento("AB");
        } catch (DepartamentoException e) {
            assertEquals("Nome do Departamento não pode ter menos de 3 caracteres.", e.getMessage());
        }
    }

    @Test
    void DepartamentoNomeMaior300Caracteres() {
        try {
            Departamento departamento = new Departamento("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        } catch (DepartamentoException e) {
            assertEquals("Nome do Departamento não pode ter mais de 300 caracteres.", e.getMessage());
        }
    }

    @Test
    void cadastrarDisciplinaRepetida() throws DepartamentoException{
        Departamento departamento = new Departamento("DCX");
        Curso si = new Curso("111", "Sistemas de Informação");
        Disciplina disciplina1 = new Disciplina("123456", "POO", si);
        departamento.cadastrarDisciplina(disciplina1);
        Disciplina disciplina2 = new Disciplina("123456", "POO", si);
        try {
            departamento.cadastrarDisciplina(disciplina2);
        } catch (DepartamentoException e) {
            assertEquals("Já existe uma disciplina com o código '123456'", e.getMessage());
        }
    }

    @Test
    void cadastrarDisciplinaRepetida2() throws DepartamentoException{
        Departamento departamento = new Departamento("DCX");
        Curso si = new Curso("111", "Sistemas de Informação");
        Disciplina disciplina1 = new Disciplina("123456", "POO", si);
        departamento.cadastrarDisciplina(disciplina1);
        try {
            departamento.cadastrarDisciplina(disciplina1);
        } catch (DepartamentoException e) {
            assertEquals("Já existe uma disciplina com o código '123456'", e.getMessage());

        }
    }
}