package br.ufpb.dcx.rodrigor.atividade.sysacademico;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class SysAcademicoTest {

    @Test
    void TestSysAcademico() {

    }
}