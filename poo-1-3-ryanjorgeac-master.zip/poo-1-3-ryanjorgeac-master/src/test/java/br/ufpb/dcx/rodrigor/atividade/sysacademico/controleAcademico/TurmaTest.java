package br.ufpb.dcx.rodrigor.atividade.sysacademico.controleAcademico;

import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TurmaTest {

    @Test
    void numTurmaMaiorOuIgualAZero() throws DepartamentoException {
        Curso si = new Curso("123456", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("111111", "POO", si);
        try {
            Turma turma = new Turma(disciplina, -1);
        } catch (DepartamentoException e) {
            assertEquals("O número da turma deve ser um número maior ou igual a zero.", e.getMessage());
        }

    }

    @Test
    void turmaComDisciplinaNula() throws DepartamentoException {
        Curso si = new Curso("123456", "Sistemas de Informação");
        try {
            Turma turma = new Turma(null, 1);
        } catch (ControleAcademicoRuntimeException e) {
            assertEquals("A disciplina de uma turma não pode ser nula.", e.getMessage());
        }
    }

    @Test
    void metodoGetAlunosDeUmaTurma() throws DepartamentoException {
        Curso si = new Curso("123456", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("111111", "POO", si);
        Turma turma = new Turma(disciplina, 1);
        List<Aluno> lista = new LinkedList<>();
        assertEquals(lista, turma.getAlunos());
    }

    @Test
    void metodoGetAlunosMatriculadosDeUmaTurma() throws DepartamentoException {
        Curso si = new Curso("123456", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("111111", "POO", si);
        Turma turma = new Turma(disciplina, 1);
        List<Aluno> lista = new LinkedList<>();
        Aluno aluno = new Aluno("123123123", "Ryan");
        lista.add(aluno);
        si.cadastrarAluno(aluno);
        turma.matricularAluno(aluno);
        assertEquals(lista,turma.getAlunos());
    }

    @Test
    void matricularAlunoEmTurma() throws DepartamentoException {
        Curso si = new Curso("123456", "Sistemas de Informação");
        Disciplina disciplina = new Disciplina("111111", "POO", si);
        Turma turma = new Turma(disciplina, 1);
        Aluno aluno = new Aluno("123123123", "Ryan");
        try {
            turma.matricularAluno(aluno);
        } catch (ErroDisciplinaException e) {
            assertEquals("Aluno não cadastrado em um curso.", e.getMessage());
        }
    }
}
