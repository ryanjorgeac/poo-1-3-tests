**Universidade Federal da Paraíba - UFPB** \
**Centro de Ciências Exatas e Educação - CCAE** \
**Departamento de Ciências Exatas - DCX**

**Professor:** [Rodrigo Rebouças de Almeida](http://rodrigor.dcx.ufpb.br)

# Atividade 


Implemente testes para o SysAcademico para as seguintes regras de negócios:

## Departamento
1. O nome do departamento não pode ter menos de 3 caracteres e não pode ser maior que 300 caracteres;
2. Um departamento não pode ter disciplinas repetidas;

## Disciplina
1. O `código` de uma disciplina não pode ser null;
2. O `nome` de uma disciplina não pode ser `null` e não pode ter menos de 3 caracteres;
3. O `código` deve ter entre 6 e 10 caracteres;
4. O `código` deve ser numérico.
5. Uma disciplina deve iniciar com as turmas vazias.
6. Os números das turmas criadas devem ser sequenciais, a partir de 1.
7. A disciplina de uma turma deve ser a mesma da disciplina que a criou;
8. O curso de uma `Disciplina` não pode ser null. Se o curso for null, a Disciplina deve lançar uma `RuntimeException` com a mensagem "Curso não deve ser null";
9. Ao executar o método `getTurma(int turma)`, se a turma não existir, o método deve lançar uma exceção `TurmaInexistenteException`; 

## Turma
1. O número da turma deve ser um número maior ou igual a zero.
2. Se a turma receber uma disciplina com valor `null`, ela deve lançar uma exceção `RuntimeException`, com uma mensagem indicando o erro.
3. O método `getAlunos()` deve retornar os alunos matriculados. Se não houver aluno matriculado, o método deve retornar uma coleção vazia.
4. Só deve ser possível matricular um aluno que esteja cadastrado no curso da disciplina. Se o aluno não estiver cadastrado no curso, o método `matricularAluno()` deve lançar uma `RuntimeException`: `ErroDisciplinaException` com uma mensagem adequada.
